To run this demo
- Compile MyFormServer.java (which compiles MyFormServlet.java)
- Run MyFormServer at the commandline
- Open a browser tab to http://localhost:40013/myangulardemo.html
- Enter something in the textfield and see the response
- Go back to the terminal and examine the output

